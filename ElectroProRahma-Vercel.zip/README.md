# Electro Pro Rahma — Vercel

This package connects the landing page to the client's existing application.
It does not connect Google Sheets or send Gmail notifications.

## Installation

1. Upload index.html, vercel.json and the api folder to the root of the existing GitHub repository. Preserve api/orders.js as a folder and file.
2. In Vercel use Framework Preset: Other; leave Build Command and Output Directory at their defaults (no custom build command or output folder).
3. Deploy the updated repository. The page sends orders to /api/orders; Vercel forwards them to the client application.
4. Test using fictitious data, then verify that the order appears in the client application and that the page displays its returned ID.

No environment variables are required by this version. Existing Google Apps Script code runs in Google Apps Script, not in Vercel. It is a separate integration.

## Verification and limits

Local mocked tests verify forwarding, backend failures, malformed replies and missing IDs. No real order was submitted. The application's POST response schema and validation rules are not confirmed. Test phone/address values pass through this package but the application may reject them.

The backend must enforce uniqueness of requestKey to avoid duplicate orders on retries. Forwarding requestKey alone does not prove the application supports it. If the request times out or the reply lacks an ID, check the application before retrying.

References:
- https://vercel.com/docs/functions/runtimes/node-js
- https://developers.google.com/apps-script/guides/web
